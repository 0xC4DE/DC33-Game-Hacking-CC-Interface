print("I'm useless!")
