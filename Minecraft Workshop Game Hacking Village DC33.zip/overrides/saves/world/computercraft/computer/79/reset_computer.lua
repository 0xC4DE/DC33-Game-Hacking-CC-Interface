local computers = {22,25,35,50,51,54,55,56,58,59,61,64,65,66,67,68,70,71,72,73}
local receiver = filesHosts[selectedPuzzle]
local funcs = {}
for i=1, 10 do
    local f = (function() filesHosts[tostring(i)] = rednet.lookup("files", "puzzle"..i) end)
    table.insert(funcs, f)
end
parallel.waitForAll(unpack(funcs))

local function resetPuzzles()
    for k,id in pairs(filesHost) do
        rednet.send(id, "", "reset")
    end
end

local function shutdown()
    for _,id in pairs(computers) do
        commands.exec("computercraft shutdown " .. id)
    end
end

local function turnon()
    for _,id in pairs(computers) do
        commands.exec("computercraft turn-on " .. id)
    end
end


os.pullEvent("redstone")
resetPuzzles()
shutdown()
turnon()
print("reset computers")