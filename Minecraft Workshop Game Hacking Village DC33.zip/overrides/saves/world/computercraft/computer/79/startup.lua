
shell.execute("/rom/modules/command/reset_computer.lua")
