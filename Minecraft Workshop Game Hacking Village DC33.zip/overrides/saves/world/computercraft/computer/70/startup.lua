shell.execute("rom/modules/command/final_puzzle_control.lua")
