shell.execute("/rom/modules/command/control_computer.lua")
