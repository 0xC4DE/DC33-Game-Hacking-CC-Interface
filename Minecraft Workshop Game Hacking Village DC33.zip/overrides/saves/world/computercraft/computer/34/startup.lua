while true do
    turtle.refuel()
    for i=1, 3 do
        turtle.forward()
        sleep(0.5)
    end
    turtle.turnLeft()
    turtle.turnLeft()
end