print("Hi!")
