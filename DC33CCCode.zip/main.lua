-- Computer Craft DC33 main computer sender and "grader" with screen

local basalt = require("basalt")

-- Get monitor and sizes
local monitor = peripheral.find("monitor") -- can use .getSize()
width, height = monitor.getSize()
width = width - 2
height = height - 2

-- Create the frame
local main = basalt.createFrame():setTerm(monitor)

-- Waiting for connection from secondary computer
local conn = peripheral.find("modem", rednet.open)
local id, message
repeat
    id, message = rednet.receive("handshake")
until message == "hello, world"


-- Button Init
local send_button = basalt.create("Button"):setSize(15, 3):setPosition(width-15, height-2):setText("Send")
main:addChild(send_button)
send_button:setBackground(colors.green)
send_button:onClick(function(element)
    print(element)
    send_button:setText("Sent!")
end)

local reset_button = basalt.create("Button"):setSize(15,3):setPosition(4, height-2):setText("Reset Puzzle")
main:addChild(reset_button)
reset_button:setBackground(colors.red)
reset_button:onClick(function(element)
    print(element)
    reset_button:setText("Reset!")
end)

basalt.run()